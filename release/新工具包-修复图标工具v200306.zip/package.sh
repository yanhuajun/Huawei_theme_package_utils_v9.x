python ./package.py
