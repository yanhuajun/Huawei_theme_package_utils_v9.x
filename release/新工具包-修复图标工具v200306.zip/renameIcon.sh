python ./renameIcon.py
