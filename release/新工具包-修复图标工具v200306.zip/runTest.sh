python ./runTest.py
